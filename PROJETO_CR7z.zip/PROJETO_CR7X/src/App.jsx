import React, { useState, useRef, useEffect } from "react";
import { Trophy, Star, Shield, ChevronRight, X, Quote, Flame, Target, Award } from "lucide-react";

/* ------------------------------------------------------------------ */
/* DATA                                                                 */
/* ------------------------------------------------------------------ */

const GOLS_ATUAIS = 978; // atualizado em 28/08/2026 — ajuste conforme novos gols
const GOLS_META = 1000;
const GOLS_RESTANTES = GOLS_META - GOLS_ATUAIS;
const GOLS_PERCENTUAL = (GOLS_ATUAIS / GOLS_META) * 100;

const NAV = [
  { id: "home", label: "Início" },
  { id: "bio", label: "Biografia" },
  { id: "carreira", label: "Carreira" },
  { id: "titulos", label: "Títulos" },
  { id: "stats", label: "Estatísticas" },
  { id: "portugal", label: "Seleção" },
  { id: "recordes", label: "Recordes" },
  { id: "momentos", label: "Momentos" },
  { id: "galeria", label: "Galeria" },
  { id: "frases", label: "Frases" },
  { id: "mentalidade", label: "Mentalidade" },
  { id: "legado", label: "Legado" },
];

const CLUBS = [
  {
    nome: "Sporting CP",
    cor: "#0A7B3E",
    periodo: "2002 – 2003",
    jogos: "31",
    gols: "5",
    titulos: "Base formadora — sem títulos no elenco principal",
    momento: "Estreia profissional aos 17 anos, chamando a atenção do Manchester United num amistoso.",
    curiosidade: "Foi criticado por outros jogadores da academia por treinar mais horas que qualquer um.",
    foto: "/images/sporting",
  },
  {
    nome: "Manchester United",
    cor: "#DA020E",
    periodo: "2003 – 2009",
    jogos: "292",
    gols: "118",
    titulos: "3 Premier League · 1 Champions League (2008) · 1 Mundial de Clubes · 1 FA Cup · 2 Copas da Liga",
    momento: "Conquista sua primeira Champions League e o primeiro Ballon d'Or em 2008, aos 23 anos.",
    curiosidade: "Chegou usando a camisa 28 e recebeu a lendária 7 logo na primeira temporada.",
    foto: "/images/manchester-united-1",
  },
  {
    nome: "Real Madrid",
    cor: "#FEBE10",
    periodo: "2009 – 2018",
    jogos: "438",
    gols: "450",
    titulos: "4 Champions League · 2 La Liga · 2 Copa del Rey · 3 Supercopas da Espanha · 3 Mundiais de Clubes",
    momento: "Transferência recorde mundial na época; torna-se o maior artilheiro da história do clube.",
    curiosidade: "Marcou em três finais de Champions League consecutivas (2016, 2017, 2018).",
    foto: "/images/real-madrid",
  },
  {
    nome: "Juventus",
    cor: "#000000",
    periodo: "2018 – 2021",
    jogos: "134",
    gols: "101",
    titulos: "2 Serie A · 1 Supercopa da Itália · 1 Copa da Itália",
    momento: "Chega à Itália logo após o icônico gol de bicicleta contra a própria Juventus na Champions.",
    curiosidade: "Tornou-se o primeiro jogador a ser artilheiro máximo da Premier League, La Liga e Serie A.",
    foto: "/images/juventus",
  },
  {
    nome: "Manchester United",
    cor: "#DA020E",
    periodo: "2021 – 2022",
    jogos: "54",
    gols: "24",
    titulos: "Sem títulos nesta segunda passagem",
    momento: "Retorno emocionado ao clube que o revelou, com gols decisivos logo nas primeiras partidas.",
    curiosidade: "Marcou um hat-trick na Champions League contra o Tottenham em sua volta.",
    foto: "/images/manchester-united-2",
  },
  {
    nome: "Al-Nassr",
    cor: "#FFE600",
    periodo: "2023 – atual",
    jogos: "100+",
    gols: "100+",
    titulos: "Saudi Super Cup · Finais da Kings Cup · recorde de goleadas na Saudi Pro League",
    momento: "Torna-se o maior artilheiro estrangeiro da história do clube e populariza o futebol saudita globalmente.",
    curiosidade: "Superou a marca dos 900 e depois 950 gols oficiais na carreira já vestindo a camisa do Al-Nassr.",
    foto: "/images/al-nassr",
  },
];

const TITULOS = {
  Clubes: [
    "5 UEFA Champions League",
    "7 ligas nacionais (Inglaterra, Espanha, Itália)",
    "Diversas copas nacionais",
    "Múltiplas Supercopas",
    "3 Mundiais de Clubes da FIFA",
  ],
  Portugal: ["UEFA Euro 2016", "UEFA Nations League 2019", "UEFA Nations League 2025"],
  Individuais: [
    "5 Bolas de Ouro (2008, 2013, 2014, 2016, 2017)",
    "4 Chuteiras de Ouro europeias (recorde)",
    "Prêmio The Best da FIFA",
    "Múltiplos prêmios de Melhor Jogador da UEFA",
    "Artilheiro de diversas edições de ligas e da Champions League",
  ],
};

const STATS = [
  { label: "Gols na carreira", valor: String(GOLS_ATUAIS) },
  { label: "Jogos na carreira", valor: "1.200+" },
  { label: "Assistências", valor: "240+" },
  { label: "Champions League", valor: "5" },
  { label: "Bolas de Ouro", valor: "5" },
  { label: "Jogos por Portugal", valor: "230+" },
];

const GOLS_POR_CLUBE = [
  { clube: "Sporting", gols: 5 },
  { clube: "Man Utd (1ª)", gols: 118 },
  { clube: "Real Madrid", gols: 450 },
  { clube: "Juventus", gols: 101 },
  { clube: "Man Utd (2ª)", gols: 24 },
  { clube: "Al-Nassr", gols: 115 },
];

const RECORDES = [
  { n: "01", t: "Maior artilheiro da história do futebol", d: "Ultrapassou a marca de 900 gols oficiais e segue somando pelo Al-Nassr e por Portugal." },
  { n: "02", t: "Maior artilheiro da UEFA Champions League", d: "Recordista isolado de gols na história da competição mais disputada da Europa." },
  { n: "03", t: "Maior artilheiro de seleções nacionais", d: "Nenhum outro jogador, homem ou mulher, marcou tantos gols vestindo a camisa do seu país." },
  { n: "04", t: "Jogador com mais partidas internacionais", d: "Recordista de aparições pela seleção portuguesa, com mais de 230 jogos disputados." },
  { n: "05", t: "Único a marcar em cinco Copas do Mundo diferentes", d: "Depois ampliou o feito ao balançar as redes também em 2026, na sexta participação." },
  { n: "06", t: "Cinco Bolas de Ouro", d: "Um dos dois únicos jogadores da história a conquistar o prêmio cinco vezes." },
];

const MOMENTOS = [
  { ano: "2002", texto: "Estreia profissional pelo Sporting CP, aos 17 anos." },
  { ano: "2003", texto: "Transferência para o Manchester United, impressionando Sir Alex Ferguson." },
  { ano: "2008", texto: "Primeira Champions League e primeiro Ballon d'Or." },
  { ano: "2009", texto: "Transferência recorde mundial para o Real Madrid." },
  { ano: "2016", texto: "Conquista o primeiro grande título por Portugal na Eurocopa." },
  { ano: "2018", texto: "Gol de bicicleta antológico contra a Juventus, que viraria seu novo clube." },
  { ano: "2019", texto: "Título da primeira UEFA Nations League com Portugal." },
  { ano: "2021", texto: "Retorno emocionado ao Manchester United." },
  { ano: "2023", texto: "Chegada ao Al-Nassr e ao futebol saudita." },
  { ano: "2026", texto: "Sexta Copa do Mundo disputada, encerrando um ciclo histórico pela seleção." },
];

const GALERIA = [
  { label: "Sporting", key: "sporting", cor: "#0A7B3E" },
  { label: "Manchester United", key: "manchester-united-1", cor: "#DA020E" },
  { label: "Real Madrid", key: "real-madrid", cor: "#FEBE10" },
  { label: "Juventus", key: "juventus", cor: "#000000" },
  { label: "Portugal", key: "portugal", cor: "#046A38" },
  { label: "Al-Nassr", key: "al-nassr", cor: "#FFE600" },
];

const FRASES = [
  "Talento sem trabalho não é nada.",
  "Meus objetivos sempre foram maiores que aplausos.",
  "Nasci com um dom especial e cabe a mim mostrar por que sou diferente.",
  "Não perco tempo pensando nos que não acreditam em mim.",
  "Sonhos não têm data de validade; respire fundo e persiga o que você quer.",
  "A dúvida é a mãe da desistência.",
];

/* ------------------------------------------------------------------ */
/* STYLE TOKENS                                                         */
/* ------------------------------------------------------------------ */

const styles = `
@import url('https://fonts.googleapis.com/css2?family=Anton&family=Work+Sans:wght@400;500;600;700&display=swap');

.cr7-root {
  --bg: #0c0d0f;
  --bg-raised: #17181b;
  --line: #2a2c30;
  --white: #f4f4f2;
  --muted: #9a9ca3;
  --red: #d21f3c;
  --gold: #e7b95c;
  --green: #0a7b3e;
  font-family: 'Work Sans', sans-serif;
  background: var(--bg);
  color: var(--white);
  min-height: 100vh;
}
.cr7-display {
  font-family: 'Anton', sans-serif;
  letter-spacing: 0.01em;
  text-transform: uppercase;
  line-height: 0.95;
}
.cr7-section {
  padding: 100px 6vw 60px;
  max-width: 1160px;
  margin: 0 auto;
  border-bottom: 1px solid var(--line);
  scroll-margin-top: 70px;
}
.cr7-eyebrow {
  color: var(--red);
  font-weight: 700;
  font-size: 13px;
}
.cr7-nav {
  position: sticky;
  top: 0;
  z-index: 20;
  background: rgba(12,13,15,0.92);
  backdrop-filter: blur(6px);
  border-bottom: 1px solid var(--line);
  display: flex;
  overflow-x: auto;
  gap: 4px;
  padding: 0 6vw;
}
.cr7-nav::-webkit-scrollbar { display: none; }
.cr7-nav button {
  background: none;
  border: none;
  color: var(--muted);
  font-family: 'Work Sans', sans-serif;
  font-weight: 600;
  font-size: 13px;
  padding: 16px 12px;
  cursor: pointer;
  white-space: nowrap;
  border-bottom: 3px solid transparent;
  transition: color .15s ease, border-color .15s ease;
}
.cr7-nav button:hover { color: var(--white); }
.cr7-nav button.active { color: var(--white); border-color: var(--red); }

.cr7-card {
  background: var(--bg-raised);
  border: 1px solid var(--line);
  padding: 24px;
}
.cr7-btn {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  background: var(--red);
  color: var(--white);
  font-weight: 700;
  padding: 14px 26px;
  border: none;
  cursor: pointer;
  font-size: 14px;
}
.cr7-btn:hover { filter: brightness(1.1); }
.cr7-btn.ghost {
  background: transparent;
  border: 1px solid var(--line);
  color: var(--white);
}
.cr7-lightbox {
  position: fixed;
  inset: 0;
  background: rgba(0,0,0,0.85);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 50;
}
.cr7-noise {
  position: fixed;
  inset: 0;
  pointer-events: none;
  z-index: 30;
  opacity: 0.05;
  mix-blend-mode: overlay;
  background-image: url("data:image/svg+xml;charset=UTF-8,%3Csvg xmlns='http://www.w3.org/2000/svg' width='140' height='140'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
}
@media (max-width: 720px) {
  .cr7-section { padding: 70px 6vw 40px; }
}
`;

/* ------------------------------------------------------------------ */
/* SUBCOMPONENTS                                                        */
/* ------------------------------------------------------------------ */

function ScoreDigits({ number, size = 44 }) {
  const digits = String(number).split("");
  return (
    <div style={{ display: "flex", gap: 6 }}>
      {digits.map((d, i) => (
        <div
          key={i}
          className="cr7-display"
          style={{
            width: size,
            height: size * 1.2,
            background: "#17181b",
            border: "1px solid var(--line)",
            borderBottom: "3px solid var(--red)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: size * 0.68,
            color: "var(--white)",
          }}
        >
          {d}
        </div>
      ))}
    </div>
  );
}

function SectionBackground({ base, position = "center 20%", strength = "strong" }) {
  const [src, setSrc] = useState(null);

  useEffect(() => {
    let cancelled = false;
    const tryExt = (i) => {
      if (i >= IMG_EXTENSIONS.length) return;
      const img = new Image();
      img.onload = () => {
        if (!cancelled) setSrc(img.src);
      };
      img.onerror = () => tryExt(i + 1);
      img.src = `${base}.${IMG_EXTENSIONS[i]}`;
    };
    tryExt(0);
    return () => {
      cancelled = true;
    };
  }, [base]);

  if (!src) return null; // sem foto ainda — seção continua igual a hoje

  const overlay =
    strength === "strong"
      ? "linear-gradient(100deg, rgba(12,13,15,0.88) 20%, rgba(12,13,15,0.6) 55%, rgba(12,13,15,0.15) 100%), linear-gradient(0deg, rgba(12,13,15,0.85) 0%, rgba(12,13,15,0.2) 40%, rgba(12,13,15,0.2) 100%)"
      : "linear-gradient(0deg, rgba(12,13,15,0.82) 0%, rgba(12,13,15,0.5) 55%, rgba(12,13,15,0.3) 100%)";

  return (
    <>
      <img
        src={src}
        alt=""
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          objectFit: "cover",
          objectPosition: position,
          zIndex: 0,
        }}
      />
      <div style={{ position: "absolute", inset: 0, background: overlay, zIndex: 0 }} />
    </>
  );
}

function JerseyBadge({ size = 84, color = "#d21f3c" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M35 8 L20 20 L8 34 L20 46 L28 40 L28 88 C28 91 30 93 33 93 L67 93 C70 93 72 91 72 88 L72 40 L80 46 L92 34 L80 20 L65 8 C65 8 60 15 50 15 C40 15 35 8 35 8 Z"
        fill={color}
        stroke="#0c0d0f"
        strokeWidth="2"
        strokeLinejoin="round"
      />
      <text
        x="50"
        y="66"
        textAnchor="middle"
        fontFamily="Anton, sans-serif"
        fontSize="34"
        fill="#0c0d0f"
      >
        7
      </text>
    </svg>
  );
}

function SectionHeading({ eyebrow, title, accent = "var(--red)", glow = true }) {
  return (
    <div style={{ marginBottom: 40, position: "relative" }}>
      {glow && (
        <div
          aria-hidden
          style={{
            position: "absolute",
            left: -60,
            top: -60,
            width: 280,
            height: 280,
            background: `radial-gradient(circle, ${accent}30 0%, transparent 70%)`,
            zIndex: 0,
            pointerEvents: "none",
          }}
        />
      )}
      <div className="cr7-eyebrow" style={{ position: "relative", zIndex: 1, color: accent }}>{eyebrow}</div>
      <h2 className="cr7-display" style={{ fontSize: "clamp(32px, 5vw, 56px)", marginTop: 6, position: "relative", zIndex: 1 }}>
        {title}
      </h2>
    </div>
  );
}

const IMG_EXTENSIONS = ["jpg", "jpeg", "png", "webp", "JPG", "JPEG", "PNG"];

function trimImageBorders(img) {
  const canvas = document.createElement("canvas");
  canvas.width = img.naturalWidth;
  canvas.height = img.naturalHeight;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0);
  const { width, height } = canvas;
  const data = ctx.getImageData(0, 0, width, height).data;
  const bgR = data[0], bgG = data[1], bgB = data[2];
  const tol = 22;
  const isBg = (idx) =>
    Math.abs(data[idx] - bgR) < tol &&
    Math.abs(data[idx + 1] - bgG) < tol &&
    Math.abs(data[idx + 2] - bgB) < tol;

  let top = 0;
  topLoop: for (; top < height; top++) {
    for (let x = 0; x < width; x += 3) {
      if (!isBg((top * width + x) * 4)) break topLoop;
    }
  }
  let bottom = height - 1;
  bottomLoop: for (; bottom > top; bottom--) {
    for (let x = 0; x < width; x += 3) {
      if (!isBg((bottom * width + x) * 4)) break bottomLoop;
    }
  }
  let left = 0;
  leftLoop: for (; left < width; left++) {
    for (let y = top; y <= bottom; y += 3) {
      if (!isBg((y * width + left) * 4)) break leftLoop;
    }
  }
  let right = width - 1;
  rightLoop: for (; right > left; right--) {
    for (let y = top; y <= bottom; y += 3) {
      if (!isBg((y * width + right) * 4)) break rightLoop;
    }
  }

  const trimmedW = right - left + 1;
  const trimmedH = bottom - top + 1;

  // Nothing meaningful to trim (degenerate) OR virtually no border found
  // (a full-bleed photo, like a flag) — don't crop, show the whole thing.
  const noBorderFound = trimmedW > width * 0.97 && trimmedH > height * 0.97;
  const degenerate = trimmedW < width * 0.12 || trimmedH < height * 0.12;
  if (noBorderFound || degenerate) {
    return { src: img.src, trimmed: false };
  }

  const marginX = Math.round(trimmedW * 0.06);
  const marginY = Math.round(trimmedH * 0.06);
  const sx = Math.max(0, left - marginX);
  const sy = Math.max(0, top - marginY);
  const sw = Math.min(width - sx, trimmedW + marginX * 2);
  const sh = Math.min(height - sy, trimmedH + marginY * 2);

  const out = document.createElement("canvas");
  out.width = sw;
  out.height = sh;
  out.getContext("2d").drawImage(canvas, sx, sy, sw, sh, 0, 0, sw, sh);
  try {
    return { src: out.toDataURL("image/png"), trimmed: true };
  } catch (e) {
    return { src: img.src, trimmed: false }; // canvas blocked (rare) — fall back
  }
}

function SmartImage({ base, alt, color = "#d21f3c", label = "", height = 220 }) {
  const [prepared, setPrepared] = useState(null); // { src, trimmed }
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setPrepared(null);
    setFailed(false);
    if (!base) {
      setFailed(true);
      return;
    }
    const tryExt = (i) => {
      if (i >= IMG_EXTENSIONS.length) {
        if (!cancelled) setFailed(true);
        return;
      }
      const img = new Image();
      img.onload = () => {
        if (cancelled) return;
        let result;
        try {
          result = trimImageBorders(img);
        } catch (e) {
          result = { src: img.src, trimmed: false };
        }
        if (!cancelled) setPrepared(result);
      };
      img.onerror = () => tryExt(i + 1);
      img.src = `${base}.${IMG_EXTENSIONS[i]}`;
    };
    tryExt(0);
    return () => {
      cancelled = true;
    };
  }, [base]);

  if (failed || !prepared) {
    return <PlacePlaceholder label={label} color={color} height={height} />;
  }

  if (!prepared.trimmed) {
    // Full-bleed photo with nothing to trim — show it whole, no cropping.
    return (
      <div
        style={{
          width: "100%",
          height,
          background: "#181920",
          border: "1px solid var(--line)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxSizing: "border-box",
        }}
      >
        <img
          src={prepared.src}
          alt={alt}
          style={{ width: "100%", height: "100%", objectFit: "contain", display: "block" }}
        />
      </div>
    );
  }

  return (
    <img
      src={prepared.src}
      alt={alt}
      style={{
        width: "100%",
        height,
        objectFit: "cover",
        display: "block",
        border: "1px solid var(--line)",
      }}
    />
  );
}

function PlacePlaceholder({ label, color = "#d21f3c", height = 220 }) {
  return (
    <div
      style={{
        height,
        background: `linear-gradient(135deg, ${color}22, #17181b 70%)`,
        border: "1px solid var(--line)",
        display: "flex",
        alignItems: "flex-end",
        padding: 16,
        position: "relative",
        overflow: "hidden",
      }}
    >
      <span
        className="cr7-display"
        style={{
          position: "absolute",
          top: -30,
          right: -10,
          fontSize: 130,
          color: color + "22",
        }}
      >
        7
      </span>
      <span style={{ fontWeight: 600, color: "var(--muted)", fontSize: 14 }}>{label}</span>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* MAIN APP                                                             */
/* ------------------------------------------------------------------ */

export default function App() {
  const [active, setActive] = useState("home");
  const [clubIdx, setClubIdx] = useState(1);
  const [quoteIdx, setQuoteIdx] = useState(0);
  const [lightbox, setLightbox] = useState(null);
  const refs = useRef({});

  const scrollTo = (id) => {
    refs.current[id]?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-40% 0px -55% 0px" }
    );
    Object.values(refs.current).forEach((el) => el && observer.observe(el));
    return () => observer.disconnect();
  }, []);

  const club = CLUBS[clubIdx];
  const maxGols = Math.max(...GOLS_POR_CLUBE.map((c) => c.gols));

  return (
    <div className="cr7-root">
      <style>{styles}</style>
      <div className="cr7-noise" />

      {/* NAV */}
      <nav className="cr7-nav">
        {NAV.map((item) => (
          <button
            key={item.id}
            className={active === item.id ? "active" : ""}
            onClick={() => scrollTo(item.id)}
          >
            {item.label}
          </button>
        ))}
      </nav>

      {/* 1. HOME */}
      <section
        id="home"
        ref={(el) => (refs.current.home = el)}
        style={{
          minHeight: "88vh",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: "0 6vw",
          position: "relative",
          overflow: "hidden",
          borderBottom: "1px solid var(--line)",
        }}
      >
        <SectionBackground base="/images/hero-bg" position="center 20%" strength="strong" />
        <span
          className="cr7-display"
          style={{
            position: "absolute",
            right: "-4vw",
            top: "50%",
            transform: "translateY(-50%)",
            fontSize: "clamp(220px, 38vw, 480px)",
            color: "#ffffff08",
            zIndex: 0,
          }}
        >
          7
        </span>
        <div style={{ position: "relative", zIndex: 1, maxWidth: 780 }}>
          <JerseyBadge size={72} color="#d21f3c" />
          <div className="cr7-eyebrow" style={{ marginTop: 16 }}>Al-Nassr FC · Nº 7 · Capitão de Portugal</div>
          <h1 className="cr7-display" style={{ fontSize: "clamp(52px, 9vw, 120px)", margin: "10px 0 20px" }}>
            Cristiano<br />Ronaldo
          </h1>
          <p style={{ color: "var(--muted)", fontSize: 18, maxWidth: 520, marginBottom: 32 }}>
            Duas décadas reescrevendo os limites do futebol. Da Madeira ao topo do mundo —
            a jornada em números, títulos e recordes.
          </p>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginBottom: 48 }}>
            <button className="cr7-btn" onClick={() => scrollTo("carreira")}>
              Explorar carreira <ChevronRight size={16} />
            </button>
            <button className="cr7-btn ghost" onClick={() => scrollTo("stats")}>
              Ver estatísticas
            </button>
          </div>
          <div style={{ display: "flex", gap: 40, flexWrap: "wrap" }}>
            {[
              [String(GOLS_ATUAIS), "Gols na carreira"],
              ["1.200+", "Jogos na carreira"],
              ["16", "Gols na temporada"],
            ].map(([n, l]) => (
              <div key={l}>
                <div className="cr7-display" style={{ fontSize: 40, color: "var(--red)" }}>{n}</div>
                <div style={{ color: "var(--muted)", fontSize: 13 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Road to 1000 */}
      <section className="cr7-section" style={{ paddingTop: 48, paddingBottom: 48 }}>
        <div className="cr7-eyebrow" style={{ marginBottom: 16 }}>Road to 1000 gols</div>
        <div style={{ display: "flex", alignItems: "center", gap: 20, flexWrap: "wrap", marginBottom: 20 }}>
          <ScoreDigits number={GOLS_ATUAIS} />
          <ChevronRight size={26} color="var(--muted)" />
          <ScoreDigits number={GOLS_META} />
          <div style={{ marginLeft: "auto" }}>
            <div className="cr7-display" style={{ fontSize: 30, color: "var(--red)" }}>{GOLS_RESTANTES}</div>
            <div style={{ color: "var(--muted)", fontSize: 12 }}>gols restantes</div>
          </div>
        </div>
        <div style={{ height: 10, background: "var(--line)" }}>
          <div style={{ width: `${GOLS_PERCENTUAL}%`, height: "100%", background: "var(--red)" }} />
        </div>
        <div style={{ fontSize: 11, color: "var(--muted)", marginTop: 8 }}>
          Números atualizados em 28/08/2026 — ajuste conforme novos gols marcados.
        </div>
      </section>

      {/* 2. BIOGRAFIA */}
      <section id="bio" ref={(el) => (refs.current.bio = el)} className="cr7-section">
        <SectionHeading eyebrow="A origem" title="Biografia" />
        <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 40 }}>
          <div>
            <p style={{ lineHeight: 1.7, color: "var(--muted)", marginBottom: 16 }}>
              <strong style={{ color: "var(--white)" }}>Cristiano Ronaldo dos Santos Aveiro</strong> nasceu em
              5 de fevereiro de 1985, em Funchal, na ilha da Madeira, Portugal. Caçula de quatro irmãos,
              cresceu no bairro operário de Santo António, filho de José Dinis, jardineiro municipal e
              apanha-bolas do CF Andorinha, e de Maria Dolores, cozinheira.
            </p>
            <p style={{ lineHeight: 1.7, color: "var(--muted)", marginBottom: 16 }}>
              Começou a jogar futebol organizado aos 8 anos, no Andorinha, clube onde o pai trabalhava.
              Passou depois pelo Nacional da Madeira antes de, aos 12 anos, se mudar sozinho para o
              continente para se juntar à academia do Sporting Clube de Portugal — uma negociação que
              ajudou a saldar uma dívida entre os clubes.
            </p>
            <p style={{ lineHeight: 1.7, color: "var(--muted)" }}>
              Na academia do Sporting, destacou-se pela obsessão por treinar mais do que qualquer colega,
              muitas vezes sozinho após o horário normal. Essa disciplina o levou à estreia profissional
              em 2002, aos 17 anos, e a um amistoso que colocaria o Manchester United em sua trilha.
            </p>
          </div>
          <div style={{ display: "grid", gap: 12, alignContent: "start" }}>
            {[
              ["Nome completo", "Cristiano Ronaldo dos Santos Aveiro"],
              ["Nascimento", "5 de fevereiro de 1985"],
              ["Local", "Funchal, Madeira, Portugal"],
              ["Altura", "1,87 m"],
              ["Posição", "Atacante / Ponta"],
              ["Clube atual", "Al-Nassr FC"],
            ].map(([k, v]) => (
              <div key={k} className="cr7-card" style={{ display: "flex", justifyContent: "space-between", padding: "14px 18px" }}>
                <span style={{ color: "var(--muted)", fontSize: 14 }}>{k}</span>
                <span style={{ fontWeight: 600, fontSize: 14 }}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 3. CARREIRA */}
      <section id="carreira" ref={(el) => (refs.current.carreira = el)} className="cr7-section">
        <SectionHeading eyebrow="A trajetória" title="Carreira" />
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 32 }}>
          {CLUBS.map((c, i) => (
            <button
              key={i}
              onClick={() => setClubIdx(i)}
              className="cr7-btn"
              style={{
                background: i === clubIdx ? c.cor : "transparent",
                color: i === clubIdx ? (["#FEBE10", "#FFE600"].includes(c.cor) ? "#111" : "#fff") : "var(--muted)",
                border: `1px solid ${i === clubIdx ? c.cor : "var(--line)"}`,
              }}
            >
              {c.nome} <span style={{ opacity: 0.7, fontWeight: 400 }}>· {c.periodo}</span>
            </button>
          ))}
        </div>
        <div className="cr7-card" style={{ borderLeft: `4px solid ${club.cor}`, padding: 0, overflow: "hidden" }}>
          <SmartImage key={club.foto} base={club.foto} alt={club.nome} color={club.cor} label={club.nome} height={260} />
          <div style={{ padding: 24 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 20, marginBottom: 24 }}>
            <div>
              <div className="cr7-display" style={{ fontSize: 34 }}>{club.jogos}</div>
              <div style={{ color: "var(--muted)", fontSize: 13 }}>Jogos</div>
            </div>
            <div>
              <div className="cr7-display" style={{ fontSize: 34 }}>{club.gols}</div>
              <div style={{ color: "var(--muted)", fontSize: 13 }}>Gols</div>
            </div>
            <div>
              <div className="cr7-display" style={{ fontSize: 34 }}>{club.periodo}</div>
              <div style={{ color: "var(--muted)", fontSize: 13 }}>Período</div>
            </div>
          </div>
          <p style={{ fontSize: 13, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>Títulos</p>
          <p style={{ marginBottom: 20 }}>{club.titulos}</p>
          <p style={{ fontSize: 13, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>Momento marcante</p>
          <p style={{ marginBottom: 20, color: "var(--muted)" }}>{club.momento}</p>
          <p style={{ fontSize: 13, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 6 }}>Curiosidade</p>
          <p style={{ color: "var(--muted)" }}>{club.curiosidade}</p>
          </div>
        </div>
      </section>

      {/* 4. TÍTULOS */}
      <section id="titulos" ref={(el) => (refs.current.titulos = el)} className="cr7-section">
        <SectionHeading eyebrow="Conquistas" title="Títulos e Conquistas" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 20 }}>
          {Object.entries(TITULOS).map(([categoria, lista]) => (
            <div key={categoria} className="cr7-card">
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 16 }}>
                {categoria === "Individuais" ? <Star size={18} color="var(--gold)" /> : <Trophy size={18} color="var(--red)" />}
                <h3 style={{ fontWeight: 700, fontSize: 16 }}>{categoria}</h3>
              </div>
              <ul style={{ display: "grid", gap: 10, listStyle: "none", padding: 0, margin: 0 }}>
                {lista.map((item) => (
                  <li key={item} style={{ color: "var(--muted)", fontSize: 14, paddingLeft: 14, position: "relative" }}>
                    <span style={{ position: "absolute", left: 0, color: "var(--red)" }}>—</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* 5. ESTATÍSTICAS */}
      <section id="stats" ref={(el) => (refs.current.stats = el)} className="cr7-section">
        <SectionHeading eyebrow="Os números" title="Estatísticas" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))", gap: 16, marginBottom: 48 }}>
          {STATS.map((s) => (
            <div key={s.label} className="cr7-card" style={{ textAlign: "center" }}>
              <div className="cr7-display" style={{ fontSize: 36, color: "var(--red)" }}>{s.valor}</div>
              <div style={{ color: "var(--muted)", fontSize: 13, marginTop: 6 }}>{s.label}</div>
            </div>
          ))}
        </div>
        <p style={{ fontSize: 13, color: "var(--muted)", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 20 }}>
          Gols por clube
        </p>
        <div style={{ display: "flex", alignItems: "flex-end", gap: 18, height: 200 }}>
          {GOLS_POR_CLUBE.map((c) => (
            <div key={c.clube} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", height: "100%", justifyContent: "flex-end" }}>
              <span style={{ fontSize: 13, fontWeight: 700, marginBottom: 6 }}>{c.gols}</span>
              <div
                style={{
                  width: "100%",
                  height: `${(c.gols / maxGols) * 100}%`,
                  background: "var(--red)",
                  minHeight: 4,
                }}
              />
              <span style={{ fontSize: 11, color: "var(--muted)", marginTop: 8, textAlign: "center" }}>{c.clube}</span>
            </div>
          ))}
        </div>
      </section>

      {/* 6. CR7 EM PORTUGAL */}
      <section id="portugal" ref={(el) => (refs.current.portugal = el)} className="cr7-section">
        <SectionHeading eyebrow="Seleção nacional" title="CR7 em Portugal" accent="var(--green)" />
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }}>
          <div>
            <p style={{ lineHeight: 1.7, color: "var(--muted)", marginBottom: 16 }}>
              Estreou pela seleção portuguesa em agosto de 2003, contra o Cazaquistão, aos 18 anos.
              Tornou-se capitão em 2008 e, desde então, é a figura central de Portugal em seis Copas
              do Mundo (2006 a 2026) e cinco Eurocopas.
            </p>
            <p style={{ lineHeight: 1.7, color: "var(--muted)" }}>
              Levou a seleção ao primeiro grande título da sua história, a Eurocopa de 2016, e depois
              às duas conquistas da UEFA Nations League, em 2019 e 2025 — consolidando-se como o maior
              artilheiro de seleções nacionais da história do futebol.
            </p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, alignContent: "start" }}>
            {[
              ["230+", "Jogos por Portugal"],
              ["145", "Gols por Portugal"],
              ["6", "Copas do Mundo"],
              ["5", "Eurocopas"],
              ["1", "Euro conquistada"],
              ["2", "Nations League"],
            ].map(([n, l]) => (
              <div key={l} className="cr7-card" style={{ textAlign: "center", borderTop: "3px solid var(--green)" }}>
                <div className="cr7-display" style={{ fontSize: 28, color: "var(--green)" }}>{n}</div>
                <div style={{ color: "var(--muted)", fontSize: 12, marginTop: 4 }}>{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. RECORDES */}
      <section id="recordes" ref={(el) => (refs.current.recordes = el)} className="cr7-section">
        <SectionHeading eyebrow="Os números que fizeram história" title="Recordes" accent="var(--gold)" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 1, background: "var(--line)" }}>
          {RECORDES.map((r) => (
            <div key={r.n} className="cr7-card" style={{ border: "none" }}>
              <div className="cr7-display" style={{ fontSize: 32, color: "var(--gold)", marginBottom: 12 }}>{r.n}</div>
              <h4 style={{ fontWeight: 700, marginBottom: 8 }}>{r.t}</h4>
              <p style={{ color: "var(--muted)", fontSize: 14, lineHeight: 1.6 }}>{r.d}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 8. MOMENTOS MARCANTES */}
      <section id="momentos" ref={(el) => (refs.current.momentos = el)} className="cr7-section">
        <SectionHeading eyebrow="A linha do tempo" title="Momentos Marcantes" accent="var(--gold)" />
        <div style={{ display: "grid", gap: 0 }}>
          {MOMENTOS.map((m, i) => (
            <div key={i} style={{ display: "flex", gap: 24, padding: "18px 0", borderTop: i === 0 ? "1px solid var(--line)" : "none", borderBottom: "1px solid var(--line)" }}>
              <div className="cr7-display" style={{ fontSize: 22, color: "var(--gold)", width: 70, flexShrink: 0 }}>{m.ano}</div>
              <div style={{ color: "var(--muted)", paddingTop: 3 }}>{m.texto}</div>
            </div>
          ))}
        </div>
      </section>

      {/* 9. GALERIA */}
      <section id="galeria" ref={(el) => (refs.current.galeria = el)} className="cr7-section">
        <SectionHeading eyebrow="Por clube" title="Galeria" />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
          {GALERIA.map((g) => (
            <div key={g.key} onClick={() => setLightbox(g)} style={{ cursor: "pointer" }}>
              <SmartImage base={`/images/${g.key}`} alt={g.label} color={g.cor} label={g.label} />
            </div>
          ))}
        </div>
        {lightbox && (
          <div className="cr7-lightbox" onClick={() => setLightbox(null)}>
            <div style={{ width: "min(600px, 86vw)" }} onClick={(e) => e.stopPropagation()}>
              <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 8 }}>
                <button onClick={() => setLightbox(null)} style={{ background: "none", border: "none", color: "#fff", cursor: "pointer" }}>
                  <X size={22} />
                </button>
              </div>
              <SmartImage base={`/images/${lightbox.key}`} alt={lightbox.label} color={lightbox.cor} label={lightbox.label} height={360} />
            </div>
          </div>
        )}
      </section>

      {/* 10. FRASES */}
      <section
        id="frases"
        ref={(el) => (refs.current.frases = el)}
        className="cr7-section"
        style={{ textAlign: "center", position: "relative", overflow: "hidden" }}
      >
        <SectionBackground base="/images/frases-bg" position="center 25%" strength="soft" />
        <div style={{ position: "relative", zIndex: 1 }}>
          <SectionHeading eyebrow="Mentalidade em palavras" title="Frases" glow={false} />
          <Quote size={28} color="var(--red)" style={{ marginBottom: 20 }} />
          <p className="cr7-display" style={{ fontSize: "clamp(24px, 4vw, 38px)", maxWidth: 720, margin: "0 auto 28px", lineHeight: 1.15 }}>
            “{FRASES[quoteIdx]}”
          </p>
          <button className="cr7-btn" onClick={() => setQuoteIdx((quoteIdx + 1) % FRASES.length)}>
            Nova frase <ChevronRight size={16} />
          </button>
        </div>
      </section>

      {/* 11. MENTALIDADE */}
      <section
        id="mentalidade"
        ref={(el) => (refs.current.mentalidade = el)}
        className="cr7-section"
        style={{ position: "relative", overflow: "hidden" }}
      >
        <SectionBackground base="/images/mentalidade-bg" position="center 30%" strength="soft" />
        <div style={{ position: "relative", zIndex: 1 }}>
          <SectionHeading eyebrow="O que sustenta a longevidade" title="Mentalidade CR7" glow={false} />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 16 }}>
            {[
              [Flame, "Disciplina", "Rotina rígida de treinos, mesmo fora de temporada, sustentada há mais de vinte anos."],
              [Target, "Competitividade", "Trata cada treino e cada partida, mesmo os amistosos, como uma final."],
              [Shield, "Preparação física", "Investe pesadamente em recuperação, fisioterapia e monitoramento biométrico."],
              [Award, "Alimentação", "Dieta controlada e planejada com nutricionistas ao longo de toda a carreira."],
            ].map(([Icon, t, d]) => (
              <div key={t} className="cr7-card">
                <Icon size={20} color="var(--red)" style={{ marginBottom: 12 }} />
                <h4 style={{ fontWeight: 700, marginBottom: 8 }}>{t}</h4>
                <p style={{ color: "var(--muted)", fontSize: 14, lineHeight: 1.6 }}>{d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 12. LEGADO */}
      <section
        id="legado"
        ref={(el) => (refs.current.legado = el)}
        className="cr7-section"
        style={{ borderBottom: "none", position: "relative", overflow: "hidden" }}
      >
        <SectionBackground base="/images/legado-bg" position="center 25%" strength="soft" />
        <div style={{ position: "relative", zIndex: 1 }}>
          <SectionHeading eyebrow="O que fica" title="Legado" glow={false} />
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40, marginBottom: 40 }}>
            <p style={{ color: "var(--muted)", lineHeight: 1.7 }}>
              Cristiano Ronaldo redefiniu o que significa ser um atleta de elite: transformou o próprio
              corpo em um projeto de longo prazo e provou que a longevidade no futebol de alto nível é
              possível. Sua influência ultrapassou as quatro linhas, levando o futebol saudita a um novo
              patamar de visibilidade mundial.
            </p>
            <p style={{ color: "var(--muted)", lineHeight: 1.7 }}>
              Para Portugal, foi o jogador que trouxe os primeiros grandes títulos da seleção. Para uma
              geração inteira de jovens jogadores, tornou-se referência de trabalho duro acima do talento
              natural — a prova viva de que disciplina sustenta carreiras de duas décadas no topo.
            </p>
          </div>
          <p className="cr7-display" style={{ fontSize: "clamp(22px, 3.4vw, 34px)", maxWidth: 760 }}>
            O legado não é apenas o que você conquistou. É o que você deixou para trás.
          </p>
        </div>
      </section>
    </div>
  );
}